﻿using PddTrainingApp.Models;
using PddTrainingApp.Views;
using System.Windows;

namespace PddTrainingApp
{
    public partial class App : Application
    {
        public static User CurrentUser { get; set; }

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            var mainWindow = new MainWindow();
            mainWindow.MainFrame.Navigate(new LoginPage());
            mainWindow.Show();
        }
    }
}