﻿using PddTrainingApp.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace PddTrainingApp.Views
{
    public partial class StudentDashboardPage : Page
    {
        public string WelcomeMessage => $"Добро пожаловать, {App.CurrentUser?.FullName ?? "Студент"}!";

        public StudentDashboardPage()
        {
            InitializeComponent();
            DataContext = this;
            LoadAssignments();
            LoadStatistics();
            LoadRecentActivity();
        }

        private void LoadAssignments()
        {
            using (var context = new PddTrainingDbContext())
            {
                var assignments = context.StudentAssignments
                    .Where(a => a.StudentId == App.CurrentUser.UserId && a.IsCompleted != true)
                    .Include(a => a.Block)
                    .ToList();

                AssignmentsItemsControl.ItemsSource = assignments;

                // Скрываем секцию если нет заданий
                if (!assignments.Any())
                {
                    var assignmentsTitle = FindName("AssignmentsTitle") as TextBlock;
                    if (assignmentsTitle != null)
                        assignmentsTitle.Visibility = Visibility.Collapsed;
                    AssignmentsItemsControl.Visibility = Visibility.Collapsed;
                }
            }
        }

        private void LoadStatistics()
        {
            using (var context = new PddTrainingDbContext())
            {
                var statistics = context.Results
                    .Where(r => r.UserId == App.CurrentUser.UserId && r.IsCorrect == true)
                    .GroupBy(r => r.Question.ModuleId)
                    .Select(g => new
                    {
                        ModuleId = g.Key,
                        ModuleName = g.First().Question.Module.Name,
                        CorrectAnswers = g.Count(r => r.IsCorrect == true),
                        TotalQuestions = g.Count(),
                        Percentage = g.Count() > 0 ? (g.Count(r => r.IsCorrect == true) * 100 / g.Count()) : 0
                    })
                    .ToList();

                if (statistics.Any())
                {
                    StatisticsItemsControl.ItemsSource = statistics;
                    NoStatisticsText.Visibility = Visibility.Collapsed;
                }
                else
                {
                    StatisticsItemsControl.Visibility = Visibility.Collapsed;
                    NoStatisticsText.Visibility = Visibility.Visible;
                }
            }
        }

        private void LoadRecentActivity()
        {
            using (var context = new PddTrainingDbContext())
            {
                var today = DateTime.Today;
                var recentResults = context.Results
                    .Where(r => r.UserId == App.CurrentUser.UserId && r.Date >= today)
                    .GroupBy(r => r.Question.Module.Name)
                    .Select(g => new
                    {
                        ModuleName = g.Key,
                        Count = g.Count(),
                        Correct = g.Count(r => r.IsCorrect == true)
                    })
                    .ToList();

                var activityList = recentResults.Select(r =>
                    $"• {r.ModuleName} - {r.Count} вопросов ({r.Correct} правильных)"
                ).ToList();

                if (activityList.Any())
                {
                    RecentActivityItemsControl.ItemsSource = activityList;
                    NoActivityText.Visibility = Visibility.Collapsed;
                }
                else
                {
                    RecentActivityItemsControl.Visibility = Visibility.Collapsed;
                    NoActivityText.Visibility = Visibility.Visible;
                }
            }
        }

        private void StartAssignment_Click(object sender, RoutedEventArgs e)
        {
            var button = (Button)sender;
            int assignmentId = (int)button.Tag;

            // Теперь используем правильный конструктор
            NavigationService.Navigate(new QuestionsPage(assignmentId: assignmentId));
        }

        private void AllModules_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new ModulesPage());
        }

        private void DetailedStatistics_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Функция детальной статистики будет реализована позже", "Статистика");
        }
    }
}