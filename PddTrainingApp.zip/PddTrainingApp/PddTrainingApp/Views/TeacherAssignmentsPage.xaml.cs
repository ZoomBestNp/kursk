﻿using PddTrainingApp.Models;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace PddTrainingApp.Views
{
    public partial class TeacherAssignmentsPage : Page
    {
        public TeacherAssignmentsPage()
        {
            InitializeComponent();
            LoadModules();
        }

        private void LoadModules()
        {
            using (var context = new PddTrainingDbContext())
            {
                ModuleComboBox.ItemsSource = context.Modules.ToList();
            }
        }
        // ДОБАВЛЯЕМ НОВЫЙ КОНСТРУКТОР В КЛАСС TeacherAssignmentsPage
        public TeacherAssignmentsPage(int? studentId = null)
        {
            InitializeComponent();
            LoadModules();

            // Если передан studentId, сохраняем его для назначения конкретному студенту
            if (studentId.HasValue)
            {
                // Можно добавить логику для автоматического назначения конкретному студенту
                MessageBox.Show($"Задание будет назначено выбранному студенту (ID: {studentId.Value})");
            }
        }
        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

        private void CreateAssignmentButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(AssignmentNameTextBox.Text))
            {
                MessageBox.Show("Введите название задания");
                return;
            }

            using (var context = new PddTrainingDbContext())
            {
                var assignment = new QuestionBlock
                {
                    TeacherId = App.CurrentUser.UserId,
                    Name = AssignmentNameTextBox.Text,
                    Description = DescriptionTextBox.Text,
                    ModuleId = (ModuleComboBox.SelectedItem as Module)?.ModuleId,
                    DifficultyLevel = (DifficultyComboBox.SelectedItem as ComboBoxItem)?.Tag as int?,
                    QuestionsCount = int.TryParse(QuestionsCountTextBox.Text, out int count) ? count : 10
                };

                context.QuestionBlocks.Add(assignment);
                context.SaveChanges();

                MessageBox.Show("Задание успешно создано!", "Успех");
                NavigationService.GoBack();
            }
        }
    }
}