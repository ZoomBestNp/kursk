﻿using PddTrainingApp.Models;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace PddTrainingApp.Views
{
    public partial class TeacherStatisticsPage : Page
    {
        public TeacherStatisticsPage()
        {
            InitializeComponent();
            LoadAssignments();
        }

        private void LoadAssignments()
        {
            using (var context = new PddTrainingDbContext())
            {
                // ПОКАЗЫВАЕМ ТОЛЬКО СВОИ ЗАДАНИЯ
                var assignments = context.QuestionBlocks
                    .Where(q => q.TeacherId == App.CurrentUser.UserId)
                    .ToList();
                AssignmentComboBox.ItemsSource = assignments;
            }
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

        private void ShowStatistics_Click(object sender, RoutedEventArgs e)
        {
            var selectedAssignment = AssignmentComboBox.SelectedItem as QuestionBlock;
            if (selectedAssignment == null)
            {
                MessageBox.Show("Выберите задание");
                return;
            }

            LoadStatistics(selectedAssignment.BlockId);
        }

        private void LoadStatistics(int assignmentId)
        {
            using (var context = new PddTrainingDbContext())
            {
                var teacherId = App.CurrentUser.UserId;

                // РЕАЛЬНАЯ СТАТИСТИКА ПО ЗАДАНИЮ
                var statistics = context.StudentAssignments
                    .Where(sa => sa.BlockId == assignmentId)
                    .Where(sa => context.TeacherStudents
                        .Any(ts => ts.TeacherId == teacherId && ts.StudentId == sa.StudentId))
                    .Include(sa => sa.Student)
                    .Include(sa => sa.Block)
                    .Select(sa => new
                    {
                        StudentName = sa.Student.FullName,
                        AssignmentName = sa.Block.Name,
                        // РЕАЛЬНЫЕ ПРАВИЛЬНЫЕ ОТВЕТЫ ПО ЭТОМУ ЗАДАНИЮ
                        CorrectAnswers = context.Results
                            .Count(r => r.UserId == sa.StudentId &&
                                       r.Question.ModuleId == sa.Block.ModuleId &&
                                       r.IsCorrect == true),
                        TotalQuestions = sa.Block.QuestionsCount,
                        Percentage = sa.Block.QuestionsCount > 0 ?
                            (context.Results
                                .Count(r => r.UserId == sa.StudentId &&
                                           r.Question.ModuleId == sa.Block.ModuleId &&
                                           r.IsCorrect == true) * 100 / sa.Block.QuestionsCount) : 0,
                        Status = sa.IsCompleted == true ? "Завершено" : "В процессе",
                        StatusColor = sa.IsCompleted == true ? Brushes.Green : Brushes.Orange,
                        Score = sa.Score.HasValue ? $"{sa.Score}%" : "Не оценено"
                    })
                    .ToList();

                if (statistics.Any())
                {
                    StatisticsItemsControl.ItemsSource = statistics;
                    NoDataText.Visibility = Visibility.Collapsed;
                }
                else
                {
                    StatisticsItemsControl.ItemsSource = null;
                    NoDataText.Text = "Нет данных по выбранному заданию";
                    NoDataText.Visibility = Visibility.Visible;
                }
            }
        }
    }
}