﻿using DemWpf.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DemWpf.Pages
{
    /// <summary>
    /// Логика взаимодействия для EditProductPage.xaml
    /// </summary>
    public partial class EditProductPage : Page
    {
        private Frame _frame;
        private Product _product;
        private string _newImagePath;

        public EditProductPage(Frame frame, int productId)
        {
            InitializeComponent();
            _frame = frame;
            LoadLists();
            if(productId != 0)
            {
                LoadProduct(productId);
            }
            else
            {
                _product = new Product();
            }
        }
        private void LoadLists()
        {
            using var db = new Dem21Context();
            CategoryTextBox.ItemsSource = db.Categories.ToList();
            ManifacturerTextBox.ItemsSource = db.Manufacturers.ToList();
            SupplierTextBox.ItemsSource = db.Suppliers.ToList();

        }
        private void LoadProduct(int productId)
        {
            using var db = new Dem21Context();
            _product = db.Products.First(x => x.ProductId == productId);

            ArticleTextbox.Text = _product.Article;
            NameTextBox.Text = _product.Name;
            DescriptionTextBox.Text = _product.Description;
            PriceTextBox.Text = _product.Price.ToString();
            UnitTextBox.Text = _product.Unit;
            DiscountTextBox.Text = _product.Discount.ToString();
            AmountTextBox.Text = _product.Amount.ToString();

            CategoryTextBox.SelectedItem = _product.Category;
            ManifacturerTextBox.SelectedItem = _product.Supplier;
            SupplierTextBox.SelectedItem = _product.Supplier;
            ProductImage.Source = new BitmapImage(new Uri(_product.PhotoPath));
        }

        private void SelectImage_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
