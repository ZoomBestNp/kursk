﻿using DemWpf.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DemWpf.Pages
{
    /// <summary>
    /// Логика взаимодействия для ProductPage.xaml
    /// </summary>
    public partial class ProductPage : Page
    {
        private Frame _frame;
        private User _currentUser;
        private List<Product> _products;
        public ProductPage(Frame frame, User user)
        {
            InitializeComponent();
           

            _frame = frame;
            _currentUser = user;
           
            LoadUser();
            LoadProduct();
            LoadSupplier();

            SupplierFilterBox.SelectedIndex = 0;
            SortBox.SelectedIndex = 0;
        }
        private void LoadUser()
        {
            UserNameText.Text = _currentUser == null 
                ? "Гость" : _currentUser.FullName;

#if DEBUG
#else
            if(_currentUser !=null && (_currentUser.Role.Name =="Администратор"
                || _currentUser.Role.Name == "Менеджер"))
            {
                FilterStackPanel.Visibility = Visibility.Visible;
            }
            else
            {
                FilterStackPanel.Visibility = Visibility.Collapsed;
            }
#endif
        }
        private void LoadProduct()
        {
            using var db = new Dem21Context();

            _products = db.Products
                .Include(x=>x.Manufacturer)
                .Include(x=>x.Supplier)
                .Include(x=>x.Category).ToList();

            ProductListView.ItemsSource = _products;
        }

        private void LoadSupplier()
        {
            using var db = new Dem21Context();
            SupplierFilterBox.Items.Clear();
            SupplierFilterBox.Items.Add("Все поставщики");

            var suppliers = db.Suppliers.Select(x => x.Name);
            foreach (var supplier in suppliers)
            {
                SupplierFilterBox.Items.Add(supplier);
            }

        }

        private void FilterChanged(object sender, EventArgs e)
        {
            IEnumerable<Product> result = _products;

            string search = SearchTextBox.Text;

            if (!string.IsNullOrWhiteSpace(search))
            {
                result = result.Where(p =>
                p.Name.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                p.Description.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                p.Manufacturer.Name.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                p.Supplier.Name.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                p.Category.Name.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                p.Article.Contains(search, StringComparison.OrdinalIgnoreCase));
            }

            if(SupplierFilterBox.SelectedIndex > 0)
            {
                string supplier = SupplierFilterBox.SelectedItem.ToString();
                result = result.Where(p =>p.Supplier.Name == supplier);
            }

            switch(SortBox.SelectedIndex)
            {
                case 1:
                    result = result.OrderBy(p => p.Amount);
                    break;
                case 2:
                    result = result.OrderByDescending(p => p.Amount);
                    break;
            }
            ProductListView.ItemsSource = result.ToList();
        }

        private void ProductListView_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (_currentUser != null && _currentUser.Role.Name == "Администратор" &&
                ProductListView.SelectedItem is Product product)
            {
                _frame.Navigate(new EditProductPage(_frame,product.ProductId ));
            }
    
        }
    }
}
